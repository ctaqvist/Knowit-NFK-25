#ifndef SPOTLIGHT_H
#define SPOTLIGHT_H

void TurnSpotLightOn ();
void TurnSpotLightOff ();

#endif