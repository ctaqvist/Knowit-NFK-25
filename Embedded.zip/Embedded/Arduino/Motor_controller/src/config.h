// config.h
#ifndef CONFIG_H
#define CONFIG_H

/*Här kan man definerar buffer, pin mods och allt som används över hela Embedded koden */

#endif