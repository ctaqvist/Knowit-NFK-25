#include "MotorControllerMock.h"

// Här definierar vi den globala instansen som Drive.cpp förväntar sig:
MotorController motorController;
