
ROVER_ID = "rover-001"
SERVER_URL = "wss://terrax9.se"