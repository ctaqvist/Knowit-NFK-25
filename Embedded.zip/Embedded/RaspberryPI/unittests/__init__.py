import sys
import os

# Lägg till projektroten i sökvägen
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
